Nous avons maintenant de quoi suivre le trajet d’une question : un fichier contient les messages, un programme les envoie à notre serveur, le moteur exécute le modèle et une réponse revient. Nous savons également où conserver cette réponse pour la comparer à la suivante.

Si votre petit modèle s’est trompé, gardez cet exemple. C’est beaucoup plus intéressant qu’une capture choisie parce qu’il avait répondu parfaitement. Vous pourrez lui soumettre le même problème après un changement de modèle et vérifier si vous avez réellement gagné quelque chose.

Vous pouvez aussi arrêter là et conserver un outil très simple. Un modèle local n’a pas besoin d’être entouré de quinze services pour rendre un service. Et si aucun de vos usages ne justifie de le laisser tourner, `Ctrl+C` reste une excellente commande. 🙂

Nous avons fait tourner un modèle sur notre machine et envoyé nos premières requêtes à son serveur. Il nous manque encore quelque chose pour travailler sur un projet : une interface qui nous permette de lui montrer du code, de discuter d’une modification et, éventuellement, de lui laisser utiliser des outils.

C’est ce que nous allons installer dans la partie suivante. Nous regarderons d’abord les solutions disponibles, leur coût et ce qu’elles font de nos données. Pour l’atelier de développement, le parcours principal utilisera un modèle hébergé. Une expérience facultative, placée après l’atelier, proposera aussi de relier notre serveur local à l’éditeur pour discuter d’un extrait de code. Ce premier modèle ne devient pas un agent de code utilisable simplement parce qu’on lui ajoute une interface.

Ensuite, place au code ! Nous aurons un petit programme à comprendre, un ticket à clarifier et un comportement à corriger. Le modèle pourra nous aider, mais il faudra encore vérifier ce qu’il propose. 🙂
