En 2025, DeepSeek-R1 illustre l’importance prise par l’apprentissage par renforcement pour améliorer les performances de modèles de langage sur des tâches de raisonnement. Le rapport décrit aussi la diffusion de modèles adaptés et de versions plus petites issues de distillation.[^01-histoire-h7s4-r1model]

La **distillation** consiste à utiliser un modèle pour aider à en entraîner un autre, par exemple au moyen de réponses qu’il a produites. Réduire la précision des nombres stockés dans les poids porte un autre nom : la quantification.

Dans cette période, les systèmes peuvent consacrer davantage de calcul à une réponse, effectuer plusieurs étapes et utiliser des outils pour vérifier certains résultats. L’expérience ressemble moins à une simple complétion de phrase, même si la génération de texte reste un composant important.

Le rapport **AI Index 2026** de Stanford décrit des progrès sur différentes évaluations, mais aussi des capacités très inégales selon les tâches. Il souligne également la place de l’industrie, les questions de ressources et les difficultés à mesurer certains effets sociaux.[^01-histoire-h7s4-index]

Un score sur une épreuve ne résume donc pas tous les usages. Un système peut réussir une question difficile et échouer sur une manipulation qui nous semble banale. Dans votre projet, vos fichiers et vos contraintes constituent encore une autre épreuve.

Le rapport AI Index 2026 rassemble surtout des observations sur l’année précédente et des données disponibles au moment de sa publication.


[^01-histoire-h7s4-r1model]: [DeepSeek-AI, DeepSeek-R1 (2025)](https://arxiv.org/abs/2501.12948).
[^01-histoire-h7s4-index]: [Stanford HAI, AI Index 2026](https://hai.stanford.edu/ai-index/2026-ai-index-report).
