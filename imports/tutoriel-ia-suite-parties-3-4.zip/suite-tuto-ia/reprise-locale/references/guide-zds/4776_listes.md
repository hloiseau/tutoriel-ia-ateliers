Vous pouvez utiliser deux types de liste :

- les listes non ordonnées (comme la présente) ;
- les listes ordonnées par chiffres arabes.

C'est peut-être la syntaxe la plus intuitive du Markdown ! Il suffit de matérialiser les puces par des tirets :

```text
- Ma très belle ;
- liste ;
- à puces.
```

Ou bien par des chiffres :

```text
1. Mon premier.
2. Mon second.
3. Mon troisième.
```
Prenez simplement garde à bien sauter une ligne **avant et après** vos listes.

Pour faire une sous-liste, indentez les puces imbriquées avec **quatre** espaces :

```text
- Ma très belle ;
- liste ;
    - avec une sous-liste ;
- à puces.
```

On obtient ainsi : 

- Ma très belle ;
- liste ;
    - avec une sous-liste ;
- à puces.